## KBFS

This repository contains beta source code and releases for KBFS, an upcoming thing that does stuff.

**Warning**: This is a temporary and experimental repository, and it will
  be removed in the future.  The code in this repository does not
  represent a finalized architecture and we will probably not accept
  any external pull requests.  *We advise you not to fork this
  repository.*

**BIGGER WARNING**: The use of any code in this directory could lead to data or security loss and other sucky situations.

### Issues

We know that the tests do not compile; that is intentional.

Other issues can be submitted via [Issues](https://github.com/keybase/keybase-issues).
