// +build darwin dragonfly freebsd linux nacl netbsd openbsd solaris

package client

var CHECK = "✔"
var BADX = "✖"
var BTC = "฿"
