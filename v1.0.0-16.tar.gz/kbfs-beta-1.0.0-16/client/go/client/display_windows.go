package client

var CHECK = "OK"
var BADX = "BAD"
var BTC = "BTC"
