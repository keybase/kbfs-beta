
# OpenPGP Go Library Features needed:

1. Serializing ECDSA and ECDH private keys
1. Encrypting private keys on serlialization
1. Bzip2 support
1. Serializing OpenPGP keys that were read out of secring.gpg; otherwise, we can't make 
new GPG keys and save them back out

# Features left out (go back and add them!!!)

1. HTTP proxy support
1. HTTP proxy CA list support
1. Tor support
