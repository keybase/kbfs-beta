
Tests
 * Test various tracking breakages, including missing proof
 * Test temporary tracking failures
 * Port over test cases
