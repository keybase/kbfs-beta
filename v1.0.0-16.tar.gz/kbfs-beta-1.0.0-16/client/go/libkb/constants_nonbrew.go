// +build !brew

package libkb

const IsBrewBuild = false
