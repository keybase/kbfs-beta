// +build !release,!staging

package libkb

const DefaultRunMode = DevelRunMode
