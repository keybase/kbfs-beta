// +build brew

package libkb

const IsBrewBuild = true
