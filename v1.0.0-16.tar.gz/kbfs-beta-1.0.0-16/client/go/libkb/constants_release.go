// +build release

package libkb

// Production run mode currently still unsafe.
// This will cause the build to fail for this tag on purpose.
//const DefaultRunMode = ProductionRunMode
