// +build staging

package libkb

const DefaultRunMode = StagingRunMode
