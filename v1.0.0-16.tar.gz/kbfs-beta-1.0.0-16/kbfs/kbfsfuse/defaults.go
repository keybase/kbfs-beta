// +build !release,!staging

package main

const defaultMDServerURI = ""
const defaultBServerURI = ""
const defaultMountType = ""
const defaultClientFlag = false
