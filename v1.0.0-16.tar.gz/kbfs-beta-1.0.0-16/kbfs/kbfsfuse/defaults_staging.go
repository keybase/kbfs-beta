// +build staging

package main

const defaultMDServerURI = "mdserver.dev.keybase.io:443"
const defaultBServerURI = "bserver.dev.keybase.io:443"
const defaultMountType = "force"
const defaultClientFlag = true
