// +build release

package main

const defaultMDServerURI = ""
const defaultBServerURI = ""
const defaultMountType = "force"
const defaultClientFlag = true
